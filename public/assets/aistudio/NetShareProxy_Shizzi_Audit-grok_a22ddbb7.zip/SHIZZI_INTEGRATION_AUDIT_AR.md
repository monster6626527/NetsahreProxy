# NetShare Proxy × Shizzi — تقرير تدقيق الدمج

## الحالة
هذا الأرشيف يحتوي على سورس NetShare Proxy المرفق كما هو، مع تقرير التدقيق هذا. **لم يتم ادعاء دمج Shizzi أو نجاح بناء APK**؛ سورس Shizzi الكامل لم يكن متاحاً للقراءة/التنزيل في بيئة العمل الحالية، ودمج واجهة صورية سيكون مضللاً.

## ما ظهر في مشروع NetShare Proxy
- applicationId / namespace: `com.admin.vpnshare`.
- الواجهة مبنية بـ Kotlin وJetpack Compose.
- توجد طبقة بروكسي محلية HTTP وSOCKS5 تحت `app/src/main/java/com/admin/vpnshare/proxy/`.
- الخدمة الحالية هي `ProxyService`، وإدارة البروكسي عبر `ProxyManager`.
- `AndroidManifest.xml` لا يعلن صلاحيات Shizuku API، ولا يوجد فيه حالياً مسار TUN/Network test الخاص بـ Shizzi.
- وجود HTTP/SOCKS5 لا يعني أن التطبيق يستطيع تلقائياً مشاركة اتصال VPN مع أجهزة Hotspot؛ البروكسيات تتطلب إعداد بروكسي على العميل، بينما المطلوب هو توجيه حركة التذرينغ على مستوى النظام.

## التصميم الصحيح للدمج
1. إضافة وحدة `shizzi` أو نقل الوحدات المصدرية اللازمة من المستودع الأصلي مع الحفاظ على ترخيصه وإشعاراته.
2. نقل واجهة Shizuku binder/privileged service وآلية التحقق من التفويض، لا مجرد فحص وجود تطبيق Shizuku.
3. نقل datapath المكتوب بـ Go ومخرجاته الأصلية وإعدادات البناء اللازمة لـ gomobile/NDK؛ لا يجوز إنشاء ملف `.so` وهمي أو إعادة تسمية مكتبة غير متوافقة.
4. ربط دورة الحياة مع التطبيق: `Idle → CheckingPermission → StartingHotspot → Running → Stopping/Error`، مع إيقاف آمن عند سحب التفويض أو انقطاع VPN.
5. التعامل مع IPv4 وIPv6 معاً، ومنع التسرب خارج VPN عندما يكون وضع VPN إلزامياً.
6. دعم توافق Android 11–12 عبر فحص إمكانات Tethering module على الجهاز، وعدم افتراض أن رقم API وحده يضمن التوافق. Android 13+ هو المسار المباشر المعتاد بحسب توثيق Shizzi.
7. إبقاء HTTP/SOCKS5 الحاليين كميزات منفصلة وعدم إيقافهما عند اختيار مشاركة الإنترنت إلا وفق سلوك واضح للمستخدم.
8. اختبارات فعلية على جهاز ARM64: بدء/إيقاف hotspot، عميل Android وWindows، IPv4/IPv6، VPN متصل/غير متصل، سحب صلاحية Shizuku، إعادة تشغيل الخدمة، واستهلاك البيانات.

## مراجع المشروع الأصلي
- https://github.com/carlelieser/shizzi
- https://github.com/carlelieser/shizzi/blob/main/README.md
- https://github.com/carlelieser/shizzi/blob/main/docs/android-compatibility.md

## المطلوب لإكمال دمج فعلي قابل للبناء
أرفق أرشيف ZIP لسورس Shizzi الكامل من GitHub (Code → Download ZIP)، أو ارفع ملفات المستودع كاملة. عند توفرها يمكن نقل الوحدات الفعلية ومطابقة أسماء الحزم وGradle وGo datapath مع مشروع NetShare Proxy، ثم إجراء فحص بناء واختبارات. لا يمكن ضمان عدم وجود أخطاء دون تشغيل بناء واختبار على جهاز Android حقيقي.
