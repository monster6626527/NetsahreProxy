# NetShare Proxy — Shizzi integration

Android application combining the existing HTTP/HTTPS CONNECT and SOCKS5 proxy features with Shizzi's direct hotspot-tethering engine through Shizuku.

## Modules

- `app/`: NetShare Proxy UI, proxy engines, configuration, statistics and logs.
- `shizzi/`: Shizzi Android service/AIDL code, Shizuku integration, Tethering APEX asset and Go `datapath` module.

## Build prerequisites

- Android SDK/platform and Build Tools required by the project (compile SDK 36.1), plus Android NDK.
- JDK supported by the Gradle/Android Gradle Plugin versions in this repository.
- Go **1.26.3 or newer** and `gomobile`:

```bash
go install golang.org/x/mobile/cmd/gomobile@latest
gomobile init
./gradlew :app:assembleDebug
```

The `:shizzi` module generates `datapath.aar` during `preBuild`; the native datapath is not checked in as a prebuilt `.so` file. Build requires network access for Gradle/Maven/Go dependencies.

## Runtime requirements

Direct sharing requires Android 11+ on a compatible 64-bit ARM device and a running, authorized Shizuku service. It does not require Root, but Shizuku authorization is required. Device/OEM compatibility varies. The HTTP/SOCKS5 proxy path is separate from direct sharing.

## Validation status

See [`AUDIT_REPORT_AR.md`](AUDIT_REPORT_AR.md) and [`SHIZZI_INTEGRATION_AR.md`](SHIZZI_INTEGRATION_AR.md). Static fixes were made, but an APK build and on-device tethering tests have **not** been completed in the current environment. Do not treat this archive as a production-verified release.

## Third-party source

Shizzi source: https://github.com/carlelieser/shizzi
Review `THIRD_PARTY_NOTICES.md` and the upstream project license before distributing a derivative build.
