# دمج Shizzi داخل NetShare Proxy — ملاحظات المطور

## ما تم تغييره
- أُضيفت وحدة Android Library باسم `:shizzi` تحت المسار `shizzi/`.
- نُقلت ملفات Kotlin وAIDL وموارد Shizzi الأصلية ومحرك Go `datapath/` إلى الوحدة الجديدة.
- أُضيفت صلاحيات Shizuku وخدمات جلسة المشاركة ومربع Quick Settings والـ provider إلى Manifest الوحدة.
- أُضيفت بطاقة **DIRECT VPN SHARING** إلى الشاشة الرئيسية: تعرض حالة Shizuku، وتطلب التفويض عند الحاجة، وتبدأ/توقف خدمة المشاركة المباشرة.
- جرى تعديل ربط UserService وفتح التطبيق وتصدير التقارير لتستخدم package name الخاص بتطبيق NetShare Proxy بدل `dev.shizzi`.
- تم الإبقاء على HTTP Proxy وSOCKS5 الحاليين دون حذف ملفات محركاتهما.
- أضيف Gradle Wrapper، وأزيل اعتماد debug build على ملف `debug.keystore` غير الموجود في الأرشيف الأصلي.

## المتطلبات قبل البناء
1. Android Studio/Gradle مع Android SDK وNDK مثبتين.
2. Go بإصدار **1.26.3 أو أحدث** (حسب `datapath/go.mod`) مثبت، ثم:
   ```bash
   go install golang.org/x/mobile/cmd/gomobile@latest
   gomobile init
   ```
3. افتح جذر المشروع الذي يحتوي `settings.gradle.kts`، ثم نفّذ:
   ```bash
   ./gradlew :app:assembleDebug
   ```
4. على الجهاز المستهدف: Android 11 (API 30) أو أحدث، وتطبيق Shizuku مثبت والخدمة شغالة ومصرّح بها. لا يحتاج مسار Shizzi إلى Root، لكنه يحتاج تفويض Shizuku.

## حدود التحقق
- لم يُبنَ APK في بيئة إعداد الأرشيف هذه: لا يوجد Android SDK/NDK مضبوط، ولا `gomobile` مثبت.
- لذلك فهذا **دمج مصدر أولي يحتاج بناءً واختباراً على جهاز فعلي**، وليس إصداراً تم إثبات نجاحه. يجب اختبار منح Shizuku، بدء/إيقاف نقطة الاتصال، توجيه IPv4 وIPv6، العمل مع VPN نشط، وتعافي الخدمة عند توقف Shizuku.
- Shizzi الأصلي يوضح أن دعم Android 11/12 قد يعتمد على إصدار وحدة Tethering؛ التوافق مع أجهزة الشركات المصنّعة ليس مضموناً.
- بطاقة المشاركة المباشرة معطلة على Android أقدم من 11. وضع HTTP/SOCKS5 الحالي منفصل عن هذا المسار.

## ملاحظات المصدر
تم الإبقاء على أسماء الحزم `dev.shizzi` ومصدر محرك datapath لتقليل التعديلات على المنطق الأصلي. راجع مستودع المصدر الأصلي وشروط ترخيصه قبل نشر نسخة مشتقة:
https://github.com/carlelieser/shizzi
