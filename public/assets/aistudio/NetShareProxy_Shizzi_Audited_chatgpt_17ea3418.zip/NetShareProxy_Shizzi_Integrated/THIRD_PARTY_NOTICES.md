# Third-party source notice

Shizzi source and its Go datapath were incorporated from:
https://github.com/carlelieser/shizzi

The source archive supplied for this integration did not contain a LICENSE file. Verify the repository's current licensing terms and obtain any required permissions before distributing a derivative build. Shizuku APIs are provided by RikkaApps:
https://github.com/RikkaApps/Shizuku

NetShare Proxy's pre-existing code remains in the `app/` module.
