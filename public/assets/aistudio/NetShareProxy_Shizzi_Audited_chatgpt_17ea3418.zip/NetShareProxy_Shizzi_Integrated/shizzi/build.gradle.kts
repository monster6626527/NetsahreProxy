import java.io.File

plugins {
    alias(libs.plugins.android.library)
    alias(libs.plugins.kotlin.compose)
}

val sourceFingerprint by lazy {
    val sources = File(projectDir, "src/main/java")
    if (!sources.isDirectory) 0 else sources.walkTopDown()
        .filter { it.isFile && it.extension == "kt" }
        .sortedBy { it.path }
        .fold(7) { hash, file -> hash * 31 + file.readText().hashCode() }
}

val gomobileBind by tasks.registering(Exec::class) {
    val goModule = layout.projectDirectory.dir("datapath")
    val outputAar = layout.buildDirectory.file("gomobile/datapath.aar")
    inputs.dir(goModule)
    outputs.file(outputAar)
    val goBin = File(System.getProperty("user.home"), "go/bin")
    val ndk = android.ndkDirectory
    workingDir = goModule.asFile
    environment("PATH", "${goBin.absolutePath}:${System.getenv("PATH")}")
    environment("ANDROID_NDK_HOME", ndk.absolutePath)
    environment("ANDROID_HOME", android.sdkDirectory.absolutePath)
    doFirst {
        check(File(goBin, "gomobile").exists()) {
            "Shizzi needs Go + gomobile. Run: go install golang.org/x/mobile/cmd/gomobile@latest && gomobile init"
        }
        outputAar.get().asFile.parentFile.mkdirs()
    }
    commandLine(File(goBin, "gomobile").absolutePath, "bind", "-target=android/arm64",
        "-androidapi", "24", "-o", outputAar.get().asFile.absolutePath, ".")
}

android {
    namespace = "dev.shizzi"
    compileSdk = 35
    defaultConfig {
        minSdk = 24
        buildConfigField("int", "SERVICE_BUILD_ID", sourceFingerprint.toString())
        ndk { abiFilters += "arm64-v8a" }
    }
    buildFeatures {
        compose = true
        aidl = true
        buildConfig = true
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    packaging { resources.excludes += "/META-INF/{AL2.0,LGPL2.1}" }
}

tasks.named("preBuild") { dependsOn(gomobileBind) }

dependencies {
    implementation(files(layout.buildDirectory.file("gomobile/datapath.aar")))
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.7")
    implementation("androidx.activity:activity-compose:1.9.3")
    implementation("androidx.datastore:datastore-preferences:1.1.1")
    val composeBom = platform("androidx.compose:compose-bom:2025.11.00")
    implementation(composeBom)
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("com.materialkolor:material-color-utilities:2.1.1")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    implementation("org.lsposed.hiddenapibypass:hiddenapibypass:4.3")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-android:1.10.2")
    implementation("org.jetbrains.kotlinx:kotlinx-coroutines-core:1.10.2")
    testImplementation("junit:junit:4.13.2")
    testImplementation("org.json:json:20250107")
}
