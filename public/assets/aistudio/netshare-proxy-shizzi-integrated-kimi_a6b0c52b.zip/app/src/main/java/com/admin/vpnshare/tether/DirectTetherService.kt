package com.admin.vpnshare.tether

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import com.admin.vpnshare.MainActivity
import com.admin.vpnshare.R
import kotlinx.coroutines.*

class DirectTetherService : Service() {
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    companion object {
        const val CHANNEL_ID = "direct_tether_service_channel"
        const val NOTIFICATION_ID = 1102
        const val ACTION_START = "com.admin.vpnshare.tether.ACTION_START"
        const val ACTION_STOP = "com.admin.vpnshare.tether.ACTION_STOP"
        const val EXTRA_METHOD = "tether_method"
        const val EXTRA_UPSTREAM = "upstream_interface"
        const val EXTRA_DOWNSTREAM = "downstream_interface"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                val method = intent.getStringExtra(EXTRA_METHOD) ?: return START_NOT_STICKY
                val upstream = intent.getStringExtra(EXTRA_UPSTREAM) ?: return START_NOT_STICKY
                val downstream = intent.getStringExtra(EXTRA_DOWNSTREAM) ?: return START_NOT_STICKY

                startForegroundWithNotification("جاري بدء المشاركة المباشرة...")

                serviceScope.launch {
                    val result = ShizukuTetherManager.startDirectTethering(
                        ShizukuTetherManager.TetherMethod.valueOf(method),
                        upstream,
                        downstream
                    )

                    if (result.isSuccess) {
                        updateNotification("المشاركة المباشرة نشطة", upstream)
                    } else {
                        updateNotification("فشل بدء المشاركة", result.exceptionOrNull()?.message ?: "")
                        stopSelf()
                    }
                }
            }
            ACTION_STOP -> {
                serviceScope.launch {
                    ShizukuTetherManager.stopDirectTethering()
                    stopForeground(STOP_FOREGROUND_REMOVE)
                    stopSelf()
                }
            }
        }
        return START_STICKY
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        serviceScope.cancel()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Direct Tether Service",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "مشاركة الإنترنت المباشرة عبر Shizuku"
                setShowBadge(false)
            }
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(channel)
        }
    }

    private fun startForegroundWithNotification(content: String) {
        val notification = buildNotification("NetShare Direct Tether", content)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(NOTIFICATION_ID, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun updateNotification(title: String, content: String) {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.notify(NOTIFICATION_ID, buildNotification(title, content))
    }

    private fun buildNotification(title: String, content: String): Notification {
        val pendingIntent = PendingIntent.getActivity(
            this, 0,
            Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val stopIntent = Intent(this, DirectTetherService::class.java).apply {
            action = ACTION_STOP
        }
        val stopPendingIntent = PendingIntent.getService(
            this, 1, stopIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(R.drawable.ic_notification)
            .setOngoing(true)
            .setContentIntent(pendingIntent)
            .addAction(0, "إيقاف", stopPendingIntent)
            .build()
    }
}
