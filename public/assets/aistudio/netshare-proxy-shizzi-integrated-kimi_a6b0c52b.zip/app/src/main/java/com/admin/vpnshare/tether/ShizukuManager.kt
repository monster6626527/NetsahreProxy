package com.admin.vpnshare.tether

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

/**
 * مدير Shizuku API للتعامل مع صلاحيات Shizuku
 */
object ShizukuManager {

    private val _shizukuState = MutableStateFlow<ShizukuState>(ShizukuState.NotInstalled)
    val shizukuState: StateFlow<ShizukuState> = _shizukuState.asStateFlow()

    private val _isGranted = MutableStateFlow(false)
    val isGranted: StateFlow<Boolean> = _isGranted.asStateFlow()

    private var appContext: Context? = null

    // Shizuku State
    sealed class ShizukuState {
        object NotInstalled : ShizukuState()
        object NotRunning : ShizukuState()
        object PermissionRequired : ShizukuState()
        data class Ready(val uid: Int, val isRoot: Boolean) : ShizukuState()
    }

    // Permission Listener
    private val permissionListener = object : Shizuku.OnRequestPermissionResultListener {
        override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            _isGranted.value = granted
            updateState()
        }
    }

    fun init(context: Context) {
        if (appContext == null) {
            appContext = context.applicationContext
            Shizuku.addRequestPermissionResultListener(permissionListener)
            updateState()
        }
    }

    fun updateState() {
        val state = when {
            !isShizukuInstalled() -> ShizukuState.NotInstalled
            !isShizukuRunning() -> ShizukuState.NotRunning
            !hasPermission() -> ShizukuState.PermissionRequired
            else -> {
                val uid = getUid()
                ShizukuState.Ready(uid = uid, isRoot = uid == 0)
            }
        }
        _shizukuState.value = state
        _isGranted.value = hasPermission()
    }

    private fun isShizukuInstalled(): Boolean {
        return try {
            appContext?.packageManager?.getPackageInfo("moe.shizuku.privileged.api", 0) != null
        } catch (e: Exception) {
            false
        }
    }

    private fun isShizukuRunning(): Boolean {
        return try {
            Shizuku.pingBinder()
        } catch (e: Exception) {
            false
        }
    }

    fun hasPermission(): Boolean {
        return try {
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
        } catch (e: Exception) {
            false
        }
    }

    fun requestPermission() {
        try {
            Shizuku.requestPermission(0)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun getUid(): Int {
        return try {
            Shizuku.getUid()
        } catch (e: Exception) {
            -1
        }
    }

    fun isReady(): Boolean {
        return _shizukuState.value is ShizukuState.Ready
    }

    fun cleanup() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
    }
}
