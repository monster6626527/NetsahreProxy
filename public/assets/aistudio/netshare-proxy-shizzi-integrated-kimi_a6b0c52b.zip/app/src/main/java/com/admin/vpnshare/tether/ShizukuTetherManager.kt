package com.admin.vpnshare.tether

import android.content.Context
import android.content.pm.PackageManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import rikka.shizuku.Shizuku

/**
 * مدير المشاركة المباشرة عبر Shizuku
 * يتيح مشاركة VPN بدون Proxy (مثل Root)
 */
object ShizukuTetherManager {

    private val _isShizukuAvailable = MutableStateFlow(false)
    val isShizukuAvailable: StateFlow<Boolean> = _isShizukuAvailable.asStateFlow()

    private val _isShizukuGranted = MutableStateFlow(false)
    val isShizukuGranted: StateFlow<Boolean> = _isShizukuGranted.asStateFlow()

    private val _isTetheringActive = MutableStateFlow(false)
    val isTetheringActive: StateFlow<Boolean> = _isTetheringActive.asStateFlow()

    private val _tetherMethod = MutableStateFlow(TetherMethod.NONE)
    val tetherMethod: StateFlow<TetherMethod> = _tetherMethod.asStateFlow()

    private val _upstreamInterface = MutableStateFlow("")
    val upstreamInterface: StateFlow<String> = _upstreamInterface.asStateFlow()

    private val _downstreamInterface = MutableStateFlow("")
    val downstreamInterface: StateFlow<String> = _downstreamInterface.asStateFlow()

    private var appContext: Context? = null

    enum class TetherMethod {
        NONE,
        WIFI_HOTSPOT,
        USB_TETHERING,
        BLUETOOTH_TETHERING,
        ETHERNET_TETHERING
    }

    enum class TetherStatus {
        IDLE,
        CHECKING_PERMISSION,
        REQUESTING_PERMISSION,
        STARTING,
        ACTIVE,
        STOPPING,
        ERROR
    }

    private val _status = MutableStateFlow(TetherStatus.IDLE)
    val status: StateFlow<TetherStatus> = _status.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    // Shizuku Permission Listener
    private val permissionListener = object : Shizuku.OnRequestPermissionResultListener {
        override fun onRequestPermissionResult(requestCode: Int, grantResult: Int) {
            val granted = grantResult == PackageManager.PERMISSION_GRANTED
            _isShizukuGranted.value = granted
            if (granted) {
                _status.value = TetherStatus.IDLE
            } else {
                _status.value = TetherStatus.ERROR
                _errorMessage.value = "تم رفض صلاحية Shizuku"
            }
        }
    }

    fun init(context: Context) {
        if (appContext == null) {
            appContext = context.applicationContext
            checkShizukuAvailability()
            Shizuku.addRequestPermissionResultListener(permissionListener)
        }
    }

    fun checkShizukuAvailability() {
        try {
            // التحقق من تثبيت Shizuku
            val isInstalled = try {
                appContext?.packageManager?.getPackageInfo("moe.shizuku.privileged.api", 0) != null
            } catch (e: Exception) {
                false
            }

            // التحقق من تشغيل الخدمة
            val isRunning = try {
                Shizuku.pingBinder()
            } catch (e: Exception) {
                false
            }

            _isShizukuAvailable.value = isInstalled && isRunning

            if (isRunning) {
                checkPermission()
            }
        } catch (e: Exception) {
            _isShizukuAvailable.value = false
        }
    }

    fun checkPermission(): Boolean {
        return try {
            val granted = Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
            _isShizukuGranted.value = granted
            granted
        } catch (e: Exception) {
            _isShizukuGranted.value = false
            false
        }
    }

    fun requestPermission() {
        try {
            _status.value = TetherStatus.REQUESTING_PERMISSION
            Shizuku.requestPermission(0)
        } catch (e: Exception) {
            _status.value = TetherStatus.ERROR
            _errorMessage.value = "فشل طلب الصلاحية: ${e.message}"
        }
    }

    /**
     * بدء المشاركة المباشرة عبر Shizuku
     * هذه الطريقة تشارك VPN مباشرة بدون Proxy
     */
    suspend fun startDirectTethering(
        method: TetherMethod,
        upstreamIface: String,
        downstreamIface: String
    ): Result<Unit> {
        return try {
            if (!checkPermission()) {
                return Result.failure(Exception("صلاحية Shizuku غير ممنوحة"))
            }

            _status.value = TetherStatus.STARTING
            _tetherMethod.value = method
            _upstreamInterface.value = upstreamIface
            _downstreamInterface.value = downstreamIface

            // تنفيذ أوامر ip rule و ip route عبر Shizuku
            val commands = buildTetherCommands(method, upstreamIface, downstreamIface)

            for (cmd in commands) {
                val result = executeShellCommand(cmd)
                if (!result.isSuccess) {
                    throw Exception("فشل تنفيذ: $cmd\n${result.error}")
                }
            }

            _isTetheringActive.value = true
            _status.value = TetherStatus.ACTIVE
            Result.success(Unit)

        } catch (e: Exception) {
            _status.value = TetherStatus.ERROR
            _errorMessage.value = e.message
            Result.failure(e)
        }
    }

    /**
     * إيقاف المشاركة المباشرة
     */
    suspend fun stopDirectTethering(): Result<Unit> {
        return try {
            _status.value = TetherStatus.STOPPING

            val commands = listOf(
                "ip rule del from all lookup main",
                "ip rule del from all lookup local",
                "ip route flush table main"
            )

            for (cmd in commands) {
                executeShellCommand(cmd)
            }

            _isTetheringActive.value = false
            _status.value = TetherStatus.IDLE
            _tetherMethod.value = TetherMethod.NONE
            Result.success(Unit)

        } catch (e: Exception) {
            _status.value = TetherStatus.ERROR
            _errorMessage.value = e.message
            Result.failure(e)
        }
    }

    private fun buildTetherCommands(
        method: TetherMethod,
        upstream: String,
        downstream: String
    ): List<String> {
        return when (method) {
            TetherMethod.WIFI_HOTSPOT -> listOf(
                // تمكين IP Forwarding
                "echo 1 > /proc/sys/net/ipv4/ip_forward",
                // إضافة قواعد التوجيه
                "ip rule add from all lookup main",
                "ip rule add from all lookup local",
                // إعداد NAT
                "iptables -t nat -A POSTROUTING -o $upstream -j MASQUERADE",
                "iptables -A FORWARD -i $upstream -o $downstream -m state --state RELATED,ESTABLISHED -j ACCEPT",
                "iptables -A FORWARD -i $downstream -o $upstream -j ACCEPT"
            )
            TetherMethod.USB_TETHERING -> listOf(
                "echo 1 > /proc/sys/net/ipv4/ip_forward",
                "ip rule add from all lookup main",
                "iptables -t nat -A POSTROUTING -o $upstream -j MASQUERADE",
                "iptables -A FORWARD -i $upstream -o rndis0 -m state --state RELATED,ESTABLISHED -j ACCEPT",
                "iptables -A FORWARD -i rndis0 -o $upstream -j ACCEPT"
            )
            TetherMethod.BLUETOOTH_TETHERING -> listOf(
                "echo 1 > /proc/sys/net/ipv4/ip_forward",
                "ip rule add from all lookup main",
                "iptables -t nat -A POSTROUTING -o $upstream -j MASQUERADE",
                "iptables -A FORWARD -i $upstream -o bt-pan -m state --state RELATED,ESTABLISHED -j ACCEPT",
                "iptables -A FORWARD -i bt-pan -o $upstream -j ACCEPT"
            )
            TetherMethod.ETHERNET_TETHERING -> listOf(
                "echo 1 > /proc/sys/net/ipv4/ip_forward",
                "ip rule add from all lookup main",
                "iptables -t nat -A POSTROUTING -o $upstream -j MASQUERADE",
                "iptables -A FORWARD -i $upstream -o eth0 -m state --state RELATED,ESTABLISHED -j ACCEPT",
                "iptables -A FORWARD -i eth0 -o $upstream -j ACCEPT"
            )
            else -> emptyList()
        }
    }

    private suspend fun executeShellCommand(command: String): ShellResult {
        return try {
            val process = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            val exitCode = process.waitFor()
            val output = process.inputStream.bufferedReader().readText()
            val error = process.errorStream.bufferedReader().readText()

            ShellResult(
                exitCode = exitCode,
                output = output,
                error = error,
                isSuccess = exitCode == 0
            )
        } catch (e: Exception) {
            ShellResult(-1, "", e.message ?: "Unknown error", false)
        }
    }

    data class ShellResult(
        val exitCode: Int,
        val output: String,
        val error: String,
        val isSuccess: Boolean
    )

    fun cleanup() {
        Shizuku.removeRequestPermissionResultListener(permissionListener)
    }
}
