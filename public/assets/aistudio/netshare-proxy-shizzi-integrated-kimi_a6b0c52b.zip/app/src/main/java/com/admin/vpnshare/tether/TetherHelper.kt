package com.admin.vpnshare.tether

import android.content.Context
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities

/**
 * مساعد للحصول على معلومات الشبكة والواجهات
 */
object TetherHelper {

    /**
     * الحصول على واجهة VPN النشطة
     */
    fun getVpnInterface(context: Context): String? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networks = cm.allNetworks

        for (network in networks) {
            val caps = cm.getNetworkCapabilities(network) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN)) {
                val linkProps = cm.getLinkProperties(network) ?: continue
                return linkProps.interfaceName
            }
        }
        return null
    }

    /**
     * الحصول على واجهة WiFi أو الهوتسبوت
     */
    fun getWifiInterface(context: Context): String? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networks = cm.allNetworks

        for (network in networks) {
            val caps = cm.getNetworkCapabilities(network) ?: continue
            if (caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) {
                val linkProps = cm.getLinkProperties(network) ?: continue
                return linkProps.interfaceName
            }
        }
        return null
    }

    /**
     * الحصول على قائمة الواجهات المتاحة
     */
    fun getAvailableInterfaces(context: Context): List<String> {
        val interfaces = mutableListOf<String>()
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networks = cm.allNetworks

        for (network in networks) {
            val linkProps = cm.getLinkProperties(network) ?: continue
            val ifaceName = linkProps.interfaceName
            if (ifaceName != null && !interfaces.contains(ifaceName)) {
                interfaces.add(ifaceName)
            }
        }
        return interfaces
    }

    /**
     * التحقق من وجود VPN نشط
     */
    fun hasActiveVpn(context: Context): Boolean {
        return getVpnInterface(context) != null
    }

    /**
     * التحقق من وجود WiFi نشط
     */
    fun hasActiveWifi(context: Context): Boolean {
        return getWifiInterface(context) != null
    }

    /**
     * الحصول على معلومات الشبكة
     */
    fun getNetworkInfo(context: Context): NetworkInfo? {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val activeNetwork = cm.activeNetwork ?: return null
        val caps = cm.getNetworkCapabilities(activeNetwork) ?: return null
        val linkProps = cm.getLinkProperties(activeNetwork) ?: return null

        return NetworkInfo(
            interfaceName = linkProps.interfaceName ?: "unknown",
            hasVpn = caps.hasTransport(NetworkCapabilities.TRANSPORT_VPN),
            hasWifi = caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI),
            hasCellular = caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR),
            hasEthernet = caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
        )
    }

    data class NetworkInfo(
        val interfaceName: String,
        val hasVpn: Boolean,
        val hasWifi: Boolean,
        val hasCellular: Boolean,
        val hasEthernet: Boolean
    )
}
