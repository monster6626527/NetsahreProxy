package com.admin.vpnshare.ui.screens

import android.content.Intent
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.admin.vpnshare.tether.ShizukuTetherManager
import com.admin.vpnshare.tether.DirectTetherService
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DirectTetherScreen(
    onNavigateBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val isShizukuAvailable by ShizukuTetherManager.isShizukuAvailable.collectAsState()
    val isShizukuGranted by ShizukuTetherManager.isShizukuGranted.collectAsState()
    val isTetheringActive by ShizukuTetherManager.isTetheringActive.collectAsState()
    val tetherMethod by ShizukuTetherManager.tetherMethod.collectAsState()
    val status by ShizukuTetherManager.status.collectAsState()
    val errorMessage by ShizukuTetherManager.errorMessage.collectAsState()
    val upstream by ShizukuTetherManager.upstreamInterface.collectAsState()

    var selectedMethod by remember { mutableStateOf(ShizukuTetherManager.TetherMethod.WIFI_HOTSPOT) }
    var selectedUpstream by remember { mutableStateOf("tun0") }
    var selectedDownstream by remember { mutableStateOf("wlan0") }

    // التحقق من Shizuku عند فتح الشاشة
    LaunchedEffect(Unit) {
        ShizukuTetherManager.init(context)
        ShizukuTetherManager.checkShizukuAvailability()
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("مشاركة VPN مباشرة") },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "رجوع")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = Color.Transparent
                )
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .verticalScroll(rememberScrollState())
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // حالة Shizuku
            ShizukuStatusCard(
                isAvailable = isShizukuAvailable,
                isGranted = isShizukuGranted,
                onRequestPermission = { ShizukuTetherManager.requestPermission() }
            )

            // اختيار طريقة المشاركة
            if (isShizukuGranted) {
                TetherMethodCard(
                    selectedMethod = selectedMethod,
                    onMethodSelected = { selectedMethod = it }
                )

                // اختيار الواجهات
                InterfaceSelectionCard(
                    selectedUpstream = selectedUpstream,
                    selectedDownstream = selectedDownstream,
                    onUpstreamChange = { selectedUpstream = it },
                    onDownstreamChange = { selectedDownstream = it }
                )

                // زر البدء/الإيقاف
                TetherControlButton(
                    isActive = isTetheringActive,
                    status = status,
                    onStart = {
                        val intent = Intent(context, DirectTetherService::class.java).apply {
                            action = DirectTetherService.ACTION_START
                            putExtra(DirectTetherService.EXTRA_METHOD, selectedMethod.name)
                            putExtra(DirectTetherService.EXTRA_UPSTREAM, selectedUpstream)
                            putExtra(DirectTetherService.EXTRA_DOWNSTREAM, selectedDownstream)
                        }
                        context.startService(intent)
                    },
                    onStop = {
                        val intent = Intent(context, DirectTetherService::class.java).apply {
                            action = DirectTetherService.ACTION_STOP
                        }
                        context.startService(intent)
                    }
                )

                // معلومات النشاط
                if (isTetheringActive) {
                    ActiveTetherInfoCard(
                        method = tetherMethod,
                        upstream = upstream
                    )
                }
            }

            // رسالة الخطأ
            errorMessage?.let { msg ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(
                        containerColor = Color(0xFFFFEBEE)
                    )
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Default.Error,
                            contentDescription = null,
                            tint = Color(0xFFD32F2F)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = msg,
                            color = Color(0xFFD32F2F)
                        )
                    }
                }
            }

            // معلومات إضافية
            InfoCard()
        }
    }
}

@Composable
fun ShizukuStatusCard(
    isAvailable: Boolean,
    isGranted: Boolean,
    onRequestPermission: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = when {
                isGranted -> Color(0xFFE8F5E9)
                isAvailable -> Color(0xFFFFF8E1)
                else -> Color(0xFFFFEBEE)
            }
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    if (isGranted) Icons.Default.CheckCircle
                    else if (isAvailable) Icons.Default.Warning
                    else Icons.Default.Error,
                    contentDescription = null,
                    tint = when {
                        isGranted -> Color(0xFF4CAF50)
                        isAvailable -> Color(0xFFFFC107)
                        else -> Color(0xFFF44336)
                    }
                )
                Spacer(modifier = Modifier.width(12.dp))
                Column {
                    Text(
                        text = "حالة Shizuku",
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = when {
                            isGranted -> "✅ متصل ومصرح"
                            isAvailable -> "⚠️ متصل - يحتاج صلاحية"
                            else -> "❌ غير متصل"
                        },
                        fontSize = 14.sp,
                        color = Color.Gray
                    )
                }
            }

            if (isAvailable && !isGranted) {
                Spacer(modifier = Modifier.height(12.dp))
                Button(
                    onClick = onRequestPermission,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text("طلب صلاحية Shizuku")
                }
            }

            if (!isAvailable) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "يرجى تثبيت وتشغيل تطبيق Shizuku أولاً",
                    fontSize = 12.sp,
                    color = Color.Gray
                )
            }
        }
    }
}

@Composable
fun TetherMethodCard(
    selectedMethod: ShizukuTetherManager.TetherMethod,
    onMethodSelected: (ShizukuTetherManager.TetherMethod) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "طريقة المشاركة",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            ShizukuTetherManager.TetherMethod.values().forEach { method ->
                if (method != ShizukuTetherManager.TetherMethod.NONE) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(8.dp))
                            .background(
                                if (selectedMethod == method) Color(0xFFE3F2FD)
                                else Color.Transparent
                            )
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(
                            selected = selectedMethod == method,
                            onClick = { onMethodSelected(method) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = when (method) {
                                    ShizukuTetherManager.TetherMethod.WIFI_HOTSPOT -> "📶 نقطة اتصال WiFi"
                                    ShizukuTetherManager.TetherMethod.USB_TETHERING -> "🔌 مشاركة USB"
                                    ShizukuTetherManager.TetherMethod.BLUETOOTH_TETHERING -> "📡 مشاركة Bluetooth"
                                    ShizukuTetherManager.TetherMethod.ETHERNET_TETHERING -> "🌐 مشاركة Ethernet"
                                    else -> "غير محدد"
                                },
                                fontWeight = if (selectedMethod == method) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }
        }
    }
}

@Composable
fun InterfaceSelectionCard(
    selectedUpstream: String,
    selectedDownstream: String,
    onUpstreamChange: (String) -> Unit,
    onDownstreamChange: (String) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "إعدادات الواجهات",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(
                value = selectedUpstream,
                onValueChange = onUpstreamChange,
                label = { Text("واجهة VPN (Upstream)") },
                placeholder = { Text("tun0") },
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = selectedDownstream,
                onValueChange = onDownstreamChange,
                label = { Text("واجهة المشاركة (Downstream)") },
                placeholder = { Text("wlan0") },
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

@Composable
fun TetherControlButton(
    isActive: Boolean,
    status: ShizukuTetherManager.TetherStatus,
    onStart: () -> Unit,
    onStop: () -> Unit
) {
    val isLoading = status == ShizukuTetherManager.TetherStatus.STARTING ||
            status == ShizukuTetherManager.TetherStatus.STOPPING

    Button(
        onClick = { if (isActive) onStop() else onStart() },
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = when {
                isActive -> Color(0xFFF44336)
                else -> Color(0xFF4CAF50)
            }
        ),
        enabled = !isLoading
    ) {
        if (isLoading) {
            CircularProgressIndicator(
                modifier = Modifier.size(24.dp),
                color = Color.White
            )
            Spacer(modifier = Modifier.width(12.dp))
            Text(if (status == ShizukuTetherManager.TetherStatus.STARTING) "جاري البدء..." else "جاري الإيقاف...")
        } else {
            Icon(
                if (isActive) Icons.Default.Stop else Icons.Default.PlayArrow,
                contentDescription = null
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                if (isActive) "إيقاف المشاركة المباشرة" else "بدء المشاركة المباشرة",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

@Composable
fun ActiveTetherInfoCard(
    method: ShizukuTetherManager.TetherMethod,
    upstream: String
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFE8F5E9)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "المشاركة نشطة ✅",
                fontWeight = FontWeight.Bold,
                color = Color(0xFF4CAF50)
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text("الطريقة: ${method.name}")
            Text("واجهة VPN: $upstream")
        }
    }
}

@Composable
fun InfoCard() {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(
            containerColor = Color(0xFFE3F2FD)
        )
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "ℹ️ معلومات",
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(8.dp))
            Text(
                text = "• هذه الميزة تستخدم Shizuku لمشاركة VPN مباشرة بدون Proxy\n" +
                        "• تتطلب تثبيت تطبيق Shizuku وتفعيله\n" +
                        "• تعمل مثل صلاحيات Root بدون الحاجة لـ Root\n" +
                        "• الأجهزة المتصلة ستحصل على إنترنت VPN مباشرة",
                fontSize = 13.sp,
                lineHeight = 20.sp
            )
        }
    }
}
